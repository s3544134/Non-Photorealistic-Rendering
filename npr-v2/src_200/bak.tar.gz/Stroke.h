/*
 *  Stroke.h
 *  NPR-GP
 *
 *  This is the base class for all stroke types
 */

